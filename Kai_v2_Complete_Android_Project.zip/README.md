# Kai v2

Kai v2 is an Android microphone processor with:
- Loud preset
- Clear preset
- Deep preset
- Discord preset
- Mic gain
- Soft compression
- Limiter
- Noise gate
- Real-time microphone monitoring

IMPORTANT:
A normal Android application cannot create a system-wide virtual microphone that Discord can select as an input device. This project therefore does NOT claim to inject processed audio directly into Discord.

To make true Kai -> Discord routing, a separate supported virtual-audio/driver solution is required (normally on desktop), or a device-specific Android solution with appropriate system privileges.
