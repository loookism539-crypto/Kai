package com.kai.voice

import android.Manifest
import android.content.pm.PackageManager
import android.media.*
import android.os.Bundle
import android.widget.*
import androidx.activity.ComponentActivity
import kotlin.math.abs
import kotlin.math.tanh

class MainActivity : ComponentActivity() {
    private var record: AudioRecord? = null
    private var track: AudioTrack? = null
    private var running = false
    private var gain = 1.0f
    private var comp = .45f
    private var limit = .80f
    private var gate = .25f

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)

        val g=findViewById<SeekBar>(R.id.gain)
        val c=findViewById<SeekBar>(R.id.compression)
        val l=findViewById<SeekBar>(R.id.limiter)
        val n=findViewById<SeekBar>(R.id.gate)
        val status=findViewById<TextView>(R.id.status)
        val start=findViewById<Button>(R.id.start)

        g.setOnSeekBarChangeListener(simple { gain=it/100f })
        c.setOnSeekBarChangeListener(simple { comp=it/100f })
        l.setOnSeekBarChangeListener(simple { limit=(it/100f).coerceAtLeast(.1f) })
        n.setOnSeekBarChangeListener(simple { gate=it/100f })

        fun preset(name:String) {
            when(name) {
                "LOUD" -> { g.progress=150; c.progress=65; l.progress=85; n.progress=10 }
                "CLEAR" -> { g.progress=110; c.progress=35; l.progress=75; n.progress=35 }
                "DEEP" -> { g.progress=115; c.progress=55; l.progress=80; n.progress=20 }
                "DISCORD" -> { g.progress=105; c.progress=50; l.progress=82; n.progress=30 }
            }
        }
        findViewById<Button>(R.id.loud).setOnClickListener { preset("LOUD") }
        findViewById<Button>(R.id.clear).setOnClickListener { preset("CLEAR") }
        findViewById<Button>(R.id.deep).setOnClickListener { preset("DEEP") }
        findViewById<Button>(R.id.discord).setOnClickListener { preset("DISCORD") }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 10)

        start.setOnClickListener {
            if (running) {
                stopEngine(); status.text="● OFFLINE"; start.text="START KAI"
            } else {
                startEngine(); status.text="● KAI ACTIVE"; start.text="STOP KAI"
            }
        }
    }

    private fun simple(f:(Int)->Unit)=object:SeekBar.OnSeekBarChangeListener{
        override fun onProgressChanged(s:SeekBar?,p:Int,u:Boolean){ if(u) f(p) }
        override fun onStartTrackingTouch(s:SeekBar?){}
        override fun onStopTrackingTouch(s:SeekBar?){}
    }

    private fun startEngine() {
        val rate=48000
        val min=AudioRecord.getMinBufferSize(rate,AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT)
        record=AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION,rate,
            AudioFormat.CHANNEL_IN_MONO,AudioFormat.ENCODING_PCM_16BIT,min*2)
        track=AudioTrack(AudioManager.STREAM_MUSIC,rate,AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT,min*2,AudioTrack.MODE_STREAM)
        record!!.startRecording(); track!!.play(); running=true
        Thread {
            val buf=ShortArray(min.coerceAtLeast(1024))
            while(running){
                val count=record?.read(buf,0,buf.size) ?: 0
                for(i in 0 until count){
                    var x=buf[i]/32768f
                    if(abs(x)<gate*.03f) x=0f
                    x*=gain
                    val amount=comp.coerceIn(0f,1f)
                    x=(x*(1f-amount))+tanh(x*2f)*amount
                    x=x.coerceIn(-limit,limit)
                    buf[i]=(x*32767f).toInt().toShort()
                }
                if(count>0) track?.write(buf,0,count)
            }
        }.start()
    }

    private fun stopEngine(){
        running=false
        try{record?.stop()}catch(_:Exception){}
        try{track?.stop()}catch(_:Exception){}
        record?.release(); track?.release(); record=null; track=null
    }

    override fun onDestroy(){ stopEngine(); super.onDestroy() }
}
